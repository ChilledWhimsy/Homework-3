﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace HW_3.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            ViewData["Message"] = "Pedro's Family Friendly Christian Party's Event Planning Site.";

            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Contact page.";

            return View();
        }
        public IActionResult TODO()
        {
            ViewData["Message"] = "List of To Do's";

            return View();
        }
        public IActionResult Party_Info()
        {
            ViewData["Message"] = "Information about the party.";

            return View();
        }

        public IActionResult Error()
        {
            return View();
        }
    }
}
